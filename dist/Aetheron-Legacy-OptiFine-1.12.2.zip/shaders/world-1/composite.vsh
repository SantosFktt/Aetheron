#version 120
#define DIMENSION_NETHER
#include "/program/fullscreen.vsh"
