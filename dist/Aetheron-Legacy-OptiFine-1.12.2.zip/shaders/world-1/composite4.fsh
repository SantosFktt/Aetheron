#version 120
#define DIMENSION_NETHER
#include "/program/composite4.fsh"
