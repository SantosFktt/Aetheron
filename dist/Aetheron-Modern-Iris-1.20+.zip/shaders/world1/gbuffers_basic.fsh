#version 330 compatibility
#define DIMENSION_END
#include "/program/gbuffers_basic.fsh"
