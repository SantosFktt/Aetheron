#version 330 compatibility
#define DIMENSION_END
#include "/program/deferred1.fsh"
