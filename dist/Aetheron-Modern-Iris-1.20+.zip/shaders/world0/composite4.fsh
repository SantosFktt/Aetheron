#version 330 compatibility
#define DIMENSION_OVERWORLD
#include "/program/composite4.fsh"
